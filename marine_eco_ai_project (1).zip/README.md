# Marine Eco-AI: Oil Spill Detection Project

Marine Eco-AI is an AI-powered solution that uses satellite images to detect oil spills in the ocean. It is built using Python, TensorFlow, and Streamlit.

## How to Run

1. Install requirements:
   ```
   pip install -r requirements.txt
   ```

2. Run the Streamlit app:
   ```
   cd app
   streamlit run app.py
   ```

## Project Structure

```
marine-eco-ai/
├── app/
│   └── app.py
├── requirements.txt
└── README.md
```

*Created by Reward Edet*