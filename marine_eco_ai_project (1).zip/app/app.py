import streamlit as st
from tensorflow.keras.models import load_model
from PIL import Image
import numpy as np

IMG_SIZE = 128
st.title("Marine Eco-AI: Oil Spill Detector")

model = load_model("../models/oil_spill_detector.h5")

uploaded_file = st.file_uploader("Upload an ocean satellite image", type=["jpg", "jpeg", "png"])
if uploaded_file:
    image = Image.open(uploaded_file)
    st.image(image, caption='Uploaded Image', use_column_width=True)
    img = image.resize((IMG_SIZE, IMG_SIZE))
    img_array = np.expand_dims(np.array(img) / 255.0, axis=0)
    prediction = model.predict(img_array)[0][0]
    if prediction > 0.5:
        st.error("⚠️ Oil Spill Detected")
    else:
        st.success("✅ Clean Ocean Surface")